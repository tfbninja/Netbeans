/**
 */
var History = {
}
/**
 * @returns {undefined}
 */
History.prototype.forward = function() {};

/**
 * @returns {undefined}
 */
History.prototype.pushState = function() {};

/**
 * @returns {Object}
 */
History.prototype.state = new Object();

/**
 * @returns {Number}
 */
History.prototype.length = new Number();

/**
 * @returns {undefined}
 */
History.prototype.back = function() {};

/**
 * @returns {undefined}
 */
History.prototype.replaceState = function() {};

/**
 * @returns {undefined}
 */
History.prototype.go = function() {};

/**
 * Represents the History prototype object.
 * @syntax History.prototype
 * @static
 */
History.prototype;

