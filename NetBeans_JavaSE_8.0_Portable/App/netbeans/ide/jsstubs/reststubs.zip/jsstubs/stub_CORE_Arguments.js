/**
 */
var Arguments = {
}
/**
 * @returns {Function}
 */
Arguments.prototype.caller = new Function();

/**
 * @returns {Number}
 */
Arguments.prototype.length = new Number();

/**
 * @returns {Function}
 */
Arguments.prototype.callee = new Function();

/**
 * Represents the Arguments prototype object.
 * @syntax Arguments.prototype
 * @static
 */
Arguments.prototype;

