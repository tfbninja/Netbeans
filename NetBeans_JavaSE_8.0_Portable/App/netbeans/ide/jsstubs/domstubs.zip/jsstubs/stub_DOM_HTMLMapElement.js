/**
 * Client-side image map. See the MAP element definition in HTML 4.01.
 */
var HTMLMapElement = {
}
/**
 * Names the map (for use with usemap). See the name attribute definition in HTML 4.01.
 * @syntax hTMLMapElement.name
 * @returns {String} 
 */
HTMLMapElement.prototype.name = new String();

/**
 * The list of areas defined for the image map.
 * @syntax hTMLMapElement.areas
 * @returns {HTMLCollection} 
 */
HTMLMapElement.prototype.areas = new HTMLCollection();

/**
 * Represents the HTMLMapElement prototype object.
 * @syntax HTMLMapElement.prototype
 * @static
 */
HTMLMapElement.prototype;

