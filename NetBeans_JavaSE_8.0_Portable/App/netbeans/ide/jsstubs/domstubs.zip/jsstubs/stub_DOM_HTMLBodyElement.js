/**
 * The HTML document body. This element is always present in the DOM API, even if the tags are not present in the source document. See the BODY element definition in HTML 4.01.
 */
var HTMLBodyElement = {
}
/**
 * Document background color. See the bgcolor attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.bgColor
 * @returns {String} 
 */
HTMLBodyElement.prototype.bgColor = new String();

/**
 * Document text color. See the text attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.text
 * @returns {String} 
 */
HTMLBodyElement.prototype.text = new String();

/**
 * Color of active links (after mouse-button down, but before mouse-button up). See the alink attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.aLink
 * @returns {String} 
 */
HTMLBodyElement.prototype.aLink = new String();

/**
 * URI [IETF RFC 2396] of the background texture tile image. See the background attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.background
 * @returns {String} 
 */
HTMLBodyElement.prototype.background = new String();

/**
 * Color of links that are not active and unvisited. See the link attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.link
 * @returns {String} 
 */
HTMLBodyElement.prototype.link = new String();

/**
 * Color of links that have been visited by the user. See the vlink attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLBodyElement.vLink
 * @returns {String} 
 */
HTMLBodyElement.prototype.vLink = new String();

/**
 * Represents the HTMLBodyElement prototype object.
 * @syntax HTMLBodyElement.prototype
 * @static
 */
HTMLBodyElement.prototype;

