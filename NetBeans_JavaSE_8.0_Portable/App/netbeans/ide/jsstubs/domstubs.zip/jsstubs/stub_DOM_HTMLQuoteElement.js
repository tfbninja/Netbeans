/**
 * For the Q and BLOCKQUOTE elements. See the Q element definition in HTML 4.01.
 */
var HTMLQuoteElement = {
}
/**
 * A URI [IETF RFC 2396] designating a source document or message. See the cite attribute definition in HTML 4.01.
 * @syntax hTMLQuoteElement.cite
 * @returns {String} 
 */
HTMLQuoteElement.prototype.cite = new String();

/**
 * Represents the HTMLQuoteElement prototype object.
 * @syntax HTMLQuoteElement.prototype
 * @static
 */
HTMLQuoteElement.prototype;

