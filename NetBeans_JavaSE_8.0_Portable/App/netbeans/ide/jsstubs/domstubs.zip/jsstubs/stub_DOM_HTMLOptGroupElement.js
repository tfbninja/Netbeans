/**
 * Group options together in logical subdivisions. See the OPTGROUP element definition in HTML 4.01.
 */
var HTMLOptGroupElement = {
}
/**
 * Assigns a label to this option group. See the label attribute definition in HTML 4.01.
 * @syntax hTMLOptGroupElement.label
 * @returns {String} 
 */
HTMLOptGroupElement.prototype.label = new String();

/**
 * The control is unavailable in this context. See the disabled attribute definition in HTML 4.01.
 * @syntax hTMLOptGroupElement.disabled
 * @returns {boolean} 
 */
HTMLOptGroupElement.prototype.disabled = new boolean();

/**
 * Represents the HTMLOptGroupElement prototype object.
 * @syntax HTMLOptGroupElement.prototype
 * @static
 */
HTMLOptGroupElement.prototype;

