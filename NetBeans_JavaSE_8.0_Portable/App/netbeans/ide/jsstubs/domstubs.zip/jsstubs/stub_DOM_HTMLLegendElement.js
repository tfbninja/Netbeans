/**
 * Provides a caption for a FIELDSET grouping. See the LEGEND element definition in HTML 4.01.
 */
var HTMLLegendElement = {
}
/**
 * A single character access key to give access to the form control. See the accesskey attribute definition in HTML 4.01.
 * @syntax hTMLLegendElement.accessKey
 * @returns {String} 
 */
HTMLLegendElement.prototype.accessKey = new String();

/**
 * Returns the FORM element containing this control. Returns null if this control is not within the context of a form.
 * @syntax hTMLLegendElement.form
 * @returns {HTMLFormElement} 
 */
HTMLLegendElement.prototype.form = new HTMLFormElement();

/**
 * Text alignment relative to FIELDSET. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLLegendElement.align
 * @returns {String} 
 */
HTMLLegendElement.prototype.align = new String();

/**
 * Represents the HTMLLegendElement prototype object.
 * @syntax HTMLLegendElement.prototype
 * @static
 */
HTMLLegendElement.prototype;

