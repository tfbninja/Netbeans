/**
 * This interface allows the DOM user to create a CSSStyleSheet outside the context of a document. There is no way to associate the new CSSStyleSheet with a document in DOM Level 2.
 */
var DOMImplementationCSS = {
}
/**
 * Creates a new CSSStyleSheet.
 * @syntax dOMImplementationCSS.createCSSStyleSheet(title, media)
 * @param {String} title The advisory title. See also the Style Sheet Interfaces section.
 * @param {String} media The comma-separated list of media associated with the new style sheet. See also the Style Sheet Interfaces section.
 * @returns {CSSStyleSheet} A new CSS style sheet.
 */
DOMImplementationCSS.prototype.createCSSStyleSheet = function(title,  media) {};

/**
 * Represents the DOMImplementationCSS prototype object.
 * @syntax DOMImplementationCSS.prototype
 * @static
 */
DOMImplementationCSS.prototype;

