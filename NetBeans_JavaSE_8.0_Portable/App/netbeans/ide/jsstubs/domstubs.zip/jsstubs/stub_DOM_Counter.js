/**
 * The Counter interface is used to represent any counter or counters function value. This interface reflects the values in the underlying style property.
 */
var Counter = {
}
/**
 * This attribute is used for the identifier of the counter.
 * @syntax counter.identifier
 * @returns {String} 
 */
Counter.prototype.identifier = new String();

/**
 * This attribute is used for the style of the list.
 * @syntax counter.listStyle
 * @returns {String} 
 */
Counter.prototype.listStyle = new String();

/**
 * This attribute is used for the separator of the nested counters.
 * @syntax counter.separator
 * @returns {String} 
 */
Counter.prototype.separator = new String();

/**
 * Represents the Counter prototype object.
 * @syntax Counter.prototype
 * @static
 */
Counter.prototype;

