/**
 * The object used to represent the TH and TD elements. See the TD element definition in HTML 4.01.
 */
var HTMLTableCellElement = {
}
/**
 * Names group of related headers. See the axis attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.axis
 * @returns {String} 
 */
HTMLTableCellElement.prototype.axis = new String();

/**
 * List of id attribute values for header cells. See the headers attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.headers
 * @returns {String} 
 */
HTMLTableCellElement.prototype.headers = new String();

/**
 * Scope covered by header cells. See the scope attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.scope
 * @returns {String} 
 */
HTMLTableCellElement.prototype.scope = new String();

/**
 * The index of this cell in the row, starting from 0. This index is in document tree order and not display order.
 * @syntax hTMLTableCellElement.cellIndex
 * @returns {Number} 
 */
HTMLTableCellElement.prototype.cellIndex = new Number();

/**
 * Vertical alignment of data in cell. See the valign attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.vAlign
 * @returns {String} 
 */
HTMLTableCellElement.prototype.vAlign = new String();

/**
 * Cell width. See the width attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLTableCellElement.width
 * @returns {String} 
 */
HTMLTableCellElement.prototype.width = new String();

/**
 * Horizontal alignment of data in cell. See the align attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.align
 * @returns {String} 
 */
HTMLTableCellElement.prototype.align = new String();

/**
 * Abbreviation for header cells. See the abbr attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.abbr
 * @returns {String} 
 */
HTMLTableCellElement.prototype.abbr = new String();

/**
 * Suppress word wrapping. See the nowrap attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLTableCellElement.noWrap
 * @returns {boolean} 
 */
HTMLTableCellElement.prototype.noWrap = new boolean();

/**
 * Cell background color. See the bgcolor attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLTableCellElement.bgColor
 * @returns {String} 
 */
HTMLTableCellElement.prototype.bgColor = new String();

/**
 * Offset of alignment character. See the charoff attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.chOff
 * @returns {String} 
 */
HTMLTableCellElement.prototype.chOff = new String();

/**
 * Cell height. See the height attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLTableCellElement.height
 * @returns {String} 
 */
HTMLTableCellElement.prototype.height = new String();

/**
 * Number of columns spanned by cell. See the colspan attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.colSpan
 * @returns {Number} 
 */
HTMLTableCellElement.prototype.colSpan = new Number();

/**
 * Number of rows spanned by cell. See the rowspan attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.rowSpan
 * @returns {Number} 
 */
HTMLTableCellElement.prototype.rowSpan = new Number();

/**
 * Alignment character for cells in a column. See the char attribute definition in HTML 4.01.
 * @syntax hTMLTableCellElement.ch
 * @returns {String} 
 */
HTMLTableCellElement.prototype.ch = new String();

/**
 * Represents the HTMLTableCellElement prototype object.
 * @syntax HTMLTableCellElement.prototype
 * @static
 */
HTMLTableCellElement.prototype;

