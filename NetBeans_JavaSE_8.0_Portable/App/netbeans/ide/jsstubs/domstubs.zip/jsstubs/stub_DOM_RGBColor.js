/**
 * The RGBColor interface is used to represent any RGB color value. This interface reflects the values in the underlying style property. Hence, modifications made to the CSSPrimitiveValue objects modify the style property.A specified RGB color is not clipped (even if the number is outside the range 0-255 or 0%-100%). A computed RGB color is clipped depending on the device.Even if a style sheet can only contain an integer for a color value, the internal storage of this integer is a float, and this can be used as a float in the specified or the computed style.A color percentage value can always be converted to a number and vice versa.
 */
var RGBColor = {
}
/**
 * This attribute is used for the red value of the RGB color.
 * @syntax rGBColor.red
 * @returns {CSSPrimitiveValue} 
 */
RGBColor.prototype.red = new CSSPrimitiveValue();

/**
 * This attribute is used for the blue value of the RGB color.
 * @syntax rGBColor.blue
 * @returns {CSSPrimitiveValue} 
 */
RGBColor.prototype.blue = new CSSPrimitiveValue();

/**
 * This attribute is used for the green value of the RGB color.
 * @syntax rGBColor.green
 * @returns {CSSPrimitiveValue} 
 */
RGBColor.prototype.green = new CSSPrimitiveValue();

/**
 * Represents the RGBColor prototype object.
 * @syntax RGBColor.prototype
 * @static
 */
RGBColor.prototype;

