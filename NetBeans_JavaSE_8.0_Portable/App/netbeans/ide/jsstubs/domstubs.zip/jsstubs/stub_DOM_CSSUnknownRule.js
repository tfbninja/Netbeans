/**
 * The CSSUnknownRule interface represents an at-rule not supported by this user agent.
 */
var CSSUnknownRule = {
}
/**
 * Represents the CSSUnknownRule prototype object.
 * @syntax CSSUnknownRule.prototype
 * @static
 */
CSSUnknownRule.prototype;

