/**
 * Local change to font. See the FONT element definition in HTML 4.01. This element is deprecated in HTML 4.01.
 */
var HTMLFontElement = {
}
/**
 * Font face identifier. See the face attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLFontElement.face
 * @returns {String} 
 */
HTMLFontElement.prototype.face = new String();

/**
 * Font color. See the color attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLFontElement.color
 * @returns {String} 
 */
HTMLFontElement.prototype.color = new String();

/**
 * Font size. See the size attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLFontElement.size
 * @returns {String} 
 */
HTMLFontElement.prototype.size = new String();

/**
 * Represents the HTMLFontElement prototype object.
 * @syntax HTMLFontElement.prototype
 * @static
 */
HTMLFontElement.prototype;

