/**
 * Ordered list. See the OL element definition in HTML 4.01.
 */
var HTMLOListElement = {
}
/**
 * Reduce spacing between list items. See the compact attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLOListElement.compact
 * @returns {boolean} 
 */
HTMLOListElement.prototype.compact = new boolean();

/**
 * Starting sequence number. See the start attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLOListElement.start
 * @returns {Number} 
 */
HTMLOListElement.prototype.start = new Number();

/**
 * Numbering style. See the type attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLOListElement.type
 * @returns {String} 
 */
HTMLOListElement.prototype.type = new String();

/**
 * Represents the HTMLOListElement prototype object.
 * @syntax HTMLOListElement.prototype
 * @static
 */
HTMLOListElement.prototype;

