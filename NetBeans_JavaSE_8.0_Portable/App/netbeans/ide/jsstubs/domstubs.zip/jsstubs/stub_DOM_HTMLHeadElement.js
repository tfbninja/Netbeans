/**
 * Document head information. See the HEAD element definition in HTML 4.01.
 */
var HTMLHeadElement = {
}
/**
 * URI [IETF RFC 2396] designating a metadata profile. See the profile attribute definition in HTML 4.01.
 * @syntax hTMLHeadElement.profile
 * @returns {String} 
 */
HTMLHeadElement.prototype.profile = new String();

/**
 * Represents the HTMLHeadElement prototype object.
 * @syntax HTMLHeadElement.prototype
 * @static
 */
HTMLHeadElement.prototype;

