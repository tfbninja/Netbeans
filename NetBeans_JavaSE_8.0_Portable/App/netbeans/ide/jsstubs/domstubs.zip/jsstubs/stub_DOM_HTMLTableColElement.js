/**
 * Regroups the COL and COLGROUP elements. See the COL element definition in HTML 4.01.
 */
var HTMLTableColElement = {
}
/**
 * Offset of alignment character. See the charoff attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.chOff
 * @returns {String} 
 */
HTMLTableColElement.prototype.chOff = new String();

/**
 * Vertical alignment of cell data in column. See the valign attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.vAlign
 * @returns {String} 
 */
HTMLTableColElement.prototype.vAlign = new String();

/**
 * Horizontal alignment of cell data in column. See the align attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.align
 * @returns {String} 
 */
HTMLTableColElement.prototype.align = new String();

/**
 * Default column width. See the width attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.width
 * @returns {String} 
 */
HTMLTableColElement.prototype.width = new String();

/**
 * Alignment character for cells in a column. See the char attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.ch
 * @returns {String} 
 */
HTMLTableColElement.prototype.ch = new String();

/**
 * Indicates the number of columns in a group or affected by a grouping. See the span attribute definition in HTML 4.01.
 * @syntax hTMLTableColElement.span
 * @returns {Number} 
 */
HTMLTableColElement.prototype.span = new Number();

/**
 * Represents the HTMLTableColElement prototype object.
 * @syntax HTMLTableColElement.prototype
 * @static
 */
HTMLTableColElement.prototype;

