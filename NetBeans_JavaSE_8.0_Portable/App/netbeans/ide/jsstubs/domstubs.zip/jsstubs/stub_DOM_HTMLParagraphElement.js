/**
 * Paragraphs. See the P element definition in HTML 4.01.
 */
var HTMLParagraphElement = {
}
/**
 * Horizontal text alignment. See the align attribute definition in HTML 4.01. This attribute is deprecated in HTML 4.01.
 * @syntax hTMLParagraphElement.align
 * @returns {String} 
 */
HTMLParagraphElement.prototype.align = new String();

/**
 * Represents the HTMLParagraphElement prototype object.
 * @syntax HTMLParagraphElement.prototype
 * @static
 */
HTMLParagraphElement.prototype;

