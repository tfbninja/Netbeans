/**
 * @syntax var encoded = encodeURIComponent(str);
 * @param {String} str
 * @returns {String}
 */
function encodeURIComponent(str) {};
