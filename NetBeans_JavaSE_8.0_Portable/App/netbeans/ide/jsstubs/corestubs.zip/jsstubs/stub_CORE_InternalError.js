/**
 */
var InternalError = {
}
/**
 * Represents the InternalError prototype object.
 * @syntax InternalError.prototype
 * @static
 */
InternalError.prototype;

