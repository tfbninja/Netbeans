/**
 * @syntax escape(string)
 * @param {String} string 
 * @returns {String} 
 */
function escape(string) {};
