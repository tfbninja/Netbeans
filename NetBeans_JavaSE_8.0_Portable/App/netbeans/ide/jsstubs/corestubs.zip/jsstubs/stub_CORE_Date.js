/**
 * @syntax new Date() new Date(milliseconds) new Date(dateString) new Date(year, month, day [, hour, minute, second, millisecond ])
 * @param {Number} 
 * @returns {Date}
 */
function Date() {
}
/**
 * @syntax toLocaleDateString()
 * @returns {String}
 */
Date.prototype.toLocaleDateString = function() {};

/**
 * @syntax getUTCSeconds()
 * @returns {Number}
 */
Date.prototype.getUTCSeconds = function() {};

/**
 * @syntax setYear(year)
 * @param {Number} year
 * @returns {Number}
 */
Date.prototype.setYear = function(year) {};

/**
 * @syntax toUTCString()
 * @returns {String}
 */
Date.prototype.toUTCString = function() {};

/**
 * @syntax setUTCFullYear(year[,month[,date]])
 * @param {Number} year
 * @returns {Number}
 */
Date.prototype.setUTCFullYear = function(year) {};

/**
 * @syntax getTimezoneOffset()
 * @returns {Number}
 */
Date.prototype.getTimezoneOffset = function() {};

/**
 * @syntax getDay()
 * @returns {Number}
 */
Date.prototype.getDay = function() {};

/**
 * @syntax setUTCHours(hour[,min[,sec[,ms]]])
 * @param {Number} hour
 * @returns {Number}
 */
Date.prototype.setUTCHours = function(hour) {};

/**
 * @syntax getYear()
 * @returns {Number}
 */
Date.prototype.getYear = function() {};

/**
 * @syntax setMinutes(min[,sec[,ms]])
 * @param {Number} min
 * @returns {Number}
 */
Date.prototype.setMinutes = function(min) {};

/**
 * @syntax toISOString()
 * @returns {String}
 */
Date.prototype.toISOString = function() {};

/**
 * @syntax setMilliseconds(ms)
 * @param {Number} ms
 * @returns {Number}
 */
Date.prototype.setMilliseconds = function(ms) {};

/**
 * @syntax UTC(year,month[,date[,hours[,minutes[,seconds[,ms]]]]])
 * @param {Number} year
 * @param {Number} month
 * @returns {Number}
 * @static
 */
Date.UTC = function(year, month) {};

/**
 * @syntax getUTCDate()
 * @returns {Number}
 */
Date.prototype.getUTCDate = function() {};

/**
 * @syntax toTimeString()
 * @returns {String}
 */
Date.prototype.toTimeString = function() {};

/**
 * @syntax setSeconds(sec[,ms])
 * @param {Number} sec
 * @returns {Number}
 */
Date.prototype.setSeconds = function(sec) {};

/**
 * @syntax toDateString()
 * @returns {String}
 */
Date.prototype.toDateString = function() {};

/**
 * @syntax setUTCSeconds(sec[,ms])
 * @param {Number} sec
 * @returns {Number}
 */
Date.prototype.setUTCSeconds = function(sec) {};

/**
 * @syntax getDate()
 * @returns {Number}
 */
Date.prototype.getDate = function() {};

/**
 * @syntax setHours(hour[,min[,sec[,ms]]])
 * @param {Number} hour
 * @returns {Number}
 */
Date.prototype.setHours = function(hour) {};

/**
 * @syntax now()
 * @returns {Number}
 * @static
 */
Date.now = function() {};

/**
 * @syntax getMonth()
 * @returns {Number}
 */
Date.prototype.getMonth = function() {};

/**
 * @syntax getUTCFullYear()
 * @returns {Number}
 */
Date.prototype.getUTCFullYear = function() {};

/**
 * @syntax toString()
 * @returns {String}
 */
Date.prototype.toString = function() {};

/**
 * @syntax setUTCDate(date)
 * @param {Number} date
 * @returns {Number}
 */
Date.prototype.setUTCDate = function(date) {};

/**
 * @syntax setUTCMonth(month[,date])
 * @param {Number} month
 * @returns {Number}
 */
Date.prototype.setUTCMonth = function(month) {};

/**
 * @syntax getMinutes()
 * @returns {Number}
 */
Date.prototype.getMinutes = function() {};

/**
 * @syntax toLocaleString()
 * @returns {String}
 */
Date.prototype.toLocaleString = function() {};

/**
 * @syntax getSeconds()
 * @returns {Number}
 */
Date.prototype.getSeconds = function() {};

/**
 * @syntax getUTCMonth()
 * @returns {Number}
 */
Date.prototype.getUTCMonth = function() {};

/**
 * @syntax getFullYear()
 * @returns {Number}
 */
Date.prototype.getFullYear = function() {};

/**
 * @syntax getHours()
 * @returns {Number}
 */
Date.prototype.getHours = function() {};

/**
 * @syntax getUTCHours()
 * @returns {Number}
 */
Date.prototype.getUTCHours = function() {};

/**
 * @syntax valueOf()
 * @returns {Number}
 */
Date.prototype.valueOf = function() {};

/**
 * @syntax parse(string)
 * @param {String} string
 * @returns {Number}
 * @static
 */
Date.parse = function(string) {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Date.prototype.constructor = new Function();

/**
 * @syntax setTime(time)
 * @param {Number} time
 * @returns {Number}
 */
Date.prototype.setTime = function(time) {};

/**
 * @syntax toLocaleTimeString()
 * @returns {String}
 */
Date.prototype.toLocaleTimeString = function() {};

/**
 * @syntax setUTCMilliseconds(ms)
 * @param {Number} ms
 * @returns {Number}
 */
Date.prototype.setUTCMilliseconds = function(ms) {};

/**
 * @syntax setUTCMinutes(min[,sec[,ms]])
 * @param {Number} min
 * @returns {Number}
 */
Date.prototype.setUTCMinutes = function(min) {};

/**
 * @syntax setMonth(month[,date])
 * @param {Number} month
 * @returns {Number}
 */
Date.prototype.setMonth = function(month) {};

/**
 * @syntax getUTCMinutes()
 * @returns {Number}
 */
Date.prototype.getUTCMinutes = function() {};

/**
 * @syntax setDate(date)
 * @param {Number} date
 * @returns {Number}
 */
Date.prototype.setDate = function(date) {};

/**
 * @syntax setFullYear(year[,month[,date]])
 * @param {Number} year
 * @returns {Number}
 */
Date.prototype.setFullYear = function(year) {};

/**
 * @syntax getTime()
 * @returns {Number}
 */
Date.prototype.getTime = function() {};

/**
 * @syntax toJSON(key)
 * @returns {Number}
 */
Date.prototype.toJSON = function(key) {};

/**
 * @syntax toGMTString()
 * @returns {String}
 */
Date.prototype.toGMTString = function() {};

/**
 * @syntax getUTCDay()
 * @returns {Number}
 */
Date.prototype.getUTCDay = function() {};

/**
 * @syntax getUTCMilliseconds()
 * @returns {Number}
 */
Date.prototype.getUTCMilliseconds = function() {};

/**
 * @syntax getMilliseconds()
 * @returns {Number}
 */
Date.prototype.getMilliseconds = function() {};

/**
 * @syntax prototype
 * @returns {Number}
 * @static
 */
Date.prototype;

