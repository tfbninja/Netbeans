/**
 * @syntax new Error([message[, fileName[, lineNumber]]])
 * @param {String} 
 * @returns {Error}
 */
function Error() {
}
/**
 * @syntax message
 * @returns {String}
 */
Error.prototype.message = new String();

/**
 * @syntax name
 * @returns {String}
 */
Error.prototype.name = new String();

/**
 * @syntax toString()
 * @returns {String}
 */
Error.prototype.toString = function() {};

/**
 * @syntax constructor
 * @returns {Function}
 */
Error.prototype.constructor = new Function();

/**
 * @syntax prototype
 * @returns {Object}
 * @static
 */
Error.prototype;

