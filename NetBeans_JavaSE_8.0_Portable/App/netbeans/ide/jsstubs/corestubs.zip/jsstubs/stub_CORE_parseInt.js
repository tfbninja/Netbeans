/**
 * @syntax var intValue = parseInt(string[, radix]);
 * @param {String} string
 * @returns {Number}
 */
function parseInt(string) {};
