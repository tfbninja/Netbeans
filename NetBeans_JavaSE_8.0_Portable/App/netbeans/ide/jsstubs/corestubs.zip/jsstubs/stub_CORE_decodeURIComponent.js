/**
 * @syntax decodeURIComponent(encodedURI)
 * @param {String} encodedURI
 * @returns {String}
 */
function decodeURIComponent(encodedURI) {};
